﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Way2bill.Models
{
    public class ProductMainCategoryMaster
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Prodcatid { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string Prodcatname { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string Prodcatimage { get; set; }
    }
}
