﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Way2bill.Models
{
    public class ProductSubCategoryMaster
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Prodscid { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string Prodscname { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string Prodcatimage { get; set; }

        public int Prodpriceperunit { get; set; }

        public int Prodcatid    { get; set; }

        [Column(TypeName = "varchar(200)")]
        public string Prodscdesc { get; set; }

    }
}
